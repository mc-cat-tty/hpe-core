from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


class SCARF:
    def __init__(self) -> None: ...

    @overload
    def initialise(self, img_res: tuple[int, int], rf_size: int, alpha: float = 1.0, C: float = 0.3) -> None:
        """Initialize from receptive field size"""

    @overload
    def initialise(self, img_res: tuple[int, int], rf_res: tuple[int, int], alpha: float = 1.0, C: float = 0.3) -> None:
        """Initialize from receptive field resolution"""

    def update(self, u: int, v: int, p: int) -> None:
        """Update the surface with an incoming event: <u, v, polarity>"""

    def getSurface(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C')]:
        """Get a reference the SCARF surface as a 2D matrix"""

    def getList(self, u: int, v: int) -> list[tuple[int, int]]:
        """
        Get a list of active events, in <x, y> format, stored in the receptive at coordinates <u, v>
        """

    def getAll(self, u: int, v: int) -> list[tuple[int, int]]:
        """
        Get a list of all events, in <x, y> format, stored in the receptive at coordinates <u, v>
        """

    def getN(self) -> int:
        """Get receptive field's circular buffer capacity (max num of elements)"""

    def getScarfParams(self) -> tuple[tuple[int, int], tuple[int, int], int, tuple[int, int]]:
        """
        Get SCARF parameters as <count, dims, N, border_shift>:
        	count        : Resolution of SCARF blocks
        	dims         : Size of receptive field
        	N            : Size of ring buffer in each SCARF block
        	border_shift : (HARD CORDED) pixel values for shift size to match origin of image and origin of scarf
        """
